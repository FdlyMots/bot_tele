from kyt import *
# // Restart service 
@bot.on(events.CallbackQuery(data=b'dell-xp'))
async def dell-xp_vps(event):
	async def dell-xp_vps_(event):
		cmd = 'xp'.strip()
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Info Service Server...`")
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 10%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 35%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 40%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 50%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 70%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Server Data`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
━━━━━━━━━━━━━━━━━━━━━━━━━━ 
   **SUCCESS DELETE ALL USR EXP**
     **Version BOT : Version 2.0.1**
━━━━━━━━━━━━━━━━━━━━━━━━━━
   **Terimakasih Telah Menggunakan-**
         **Script By FvSTORE**
━━━━━━━━━━━━━━━━━━━━━━━━━━
**» 🧊@fv_stores**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await dell-xp_vps_(event)
	else:
		await event.answer("Access Denied",alert=True)